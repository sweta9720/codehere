package positioning;
import java.awt.Point;
import java.util.*;
//Class to store the intersection point

public class IntersectionPoints
{
	private double x, y;
	private List<TargetPoints> range;
	
	IntersectionPoints() 
	{
		range = new ArrayList<TargetPoints>();
	}
	
	IntersectionPoints(double x, double y) 
	{	
		this.x = x;
		this.y = y;
		range = new ArrayList<TargetPoints>();
	}

	List<TargetPoints> getPoint()
	{
		return this.range;
	}
	
	void addPoint(TargetPoints p)
	{
		if(this.range.contains(p) == false)
			range.add(p);
	}
	
	void displayList()
	{
		for(TargetPoints p : this.range)
			System.out.print("( " + (int)p.getX() + " " + (int)p.getY() + " )  ");
		System.out.println();
	}
	
	void setPoints(int x, int y) 
	{	
		this.x = x;
		this.y = y;
	}
	
	double getX()
	{
		return this.x;
	}
	double getY()
	{
		return this.y;
	}
}
