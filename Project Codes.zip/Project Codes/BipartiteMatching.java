package positioning;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;
import java.util.List;
import java.util.Random;

public class BipartiteMatching 
{
	private int MAX = 100, r = 30, SENSOR_MAX = 100, a, b, mid, c1D_length = 0;
	private double min, cstar, c1D[];
	private List<TargetPoints> points;
	private List<SensorPoints> sensor;	
	private List<double[]> cost = new ArrayList<double[]>();
	private List<int[]> adjacency = new ArrayList<int[]>();
	private int assigned_sensor[], assigned[];
	DecimalFormat df = new DecimalFormat("#.#####");
	
	BipartiteMatching(List<TargetPoints> points, List<SensorPoints> sensor, int r)
	{
		this.points = points;
		this.sensor = sensor;
		this.r = r;
		this.MAX = points.size();
		this.SENSOR_MAX = sensor.size();
		this.c1D = new double[MAX * SENSOR_MAX];
		this.assigned_sensor = new int[MAX];
		this.assigned = new int[MAX];
		this.a = 0;
		this.b = MAX * SENSOR_MAX;
		this.mid = -1;
	}
	
	private double EuclideanDist(double x1, double y1, double x2, double y2)
	{
		return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
	}
	
	private void constructCostMatrix()
	{
		double c[], z[] = new double[MAX], min, d;
		int i = 0, j;
		Formatter fm;
		
		System.out.println(MAX + "  " + SENSOR_MAX);
		
		
		for(SensorPoints s : sensor)
		{
			c = new double[MAX];
			for(TargetPoints t : points)
			{
				d = Double.parseDouble(df.format(EuclideanDist(s.getX(), s.getY(), t.getX(), t.getY())));
				if(d > r)
				{
					c[points.indexOf(t)] = Double.parseDouble(df.format(d - r));
					c1D[i++] = Double.parseDouble(df.format(d - r));
				}
				else
				{
					c[points.indexOf(t)] = 0;
					c1D[i++] = 0;
				}
			}
			cost.add(c);
		}
		

		System.out.println("COST MATRIX: ");
		for(i = 0; i < SENSOR_MAX; i++)
		{
			c = cost.get(i);
			for(j = 0; j < MAX; j++)
			{
				fm = new Formatter();
				fm.format("%-15.4f", c[j]);
				System.out.print(fm);
			}
			System.out.println();
		}
		

		for(i = 0; i < MAX; i++)
		{
			min = Double.MAX_VALUE;
			for(j = 0; j < SENSOR_MAX; j++)
			{
				c = cost.get(j);
				if(c[i] < min)
					min = c[i];
			}
			z[i] = min;
		}	
		System.out.print("Z: ");
		for(i = 0; i < z.length; i++)
			System.out.print(z[i] + " ");
		System.out.println();
		
		//To sort the cost array
		Arrays.sort(z);
		Arrays.sort(c1D);
		min = cstar = z[MAX-1];
		

		for (i = 0; i < c1D.length-1; i++) 
            if (c1D[i] != c1D[i+1]) 
                c1D[c1D_length++] = c1D[i]; 
        c1D[c1D_length++] = c1D[c1D.length-1];
        
        
        for(i = this.c1D_length; i < (this.SENSOR_MAX * this.MAX); i++)
        	this.c1D[i] = Double.MAX_VALUE;
		
		
		this.a = Arrays.binarySearch(c1D, cstar);
		this.b = c1D_length-1;
		this.mid = 0;
		
		//To display the cost array
		System.out.print("UNIQUE COST VALUES: ");
		for(i = 0; i < c1D_length; i++)
			System.out.print(c1D[i] + "\t");
		System.out.println("\nTOTAL NUMBER OF UNIQUE VALUES: " + this.c1D.length);
		
		System.out.println("\nVALUE OF Z: " + cstar);
	}
	
	private void setCstar()
	{
		int i;
		for(i = 0; i < c1D_length; i++)
			if(c1D[i] > cstar)
				break;
		
		if(i < c1D_length)
		{
			System.out.println("\n\nNEW Z-VALUE: " + c1D[i]);
			cstar = c1D[i];
		}
		else
		{
			System.out.println("ALL VALUES TRIED, NO SOLUTION FOUND");
			System.exit(0);
		}
		constructAdjacencyMatrix();
	}
	
	private void constructAdjacencyMatrix()
	{
		int i, j, a[], count, flag = 0;
		double c[];
		adjacency.clear();
		for(i = 0; i < SENSOR_MAX; i++)
		{
			a = new int[MAX];
			c = cost.get(i);
			count = 0;
			for(j = 0; j < MAX; j++)
			{
				if(c[j] <= cstar)
				{
					a[j] = 1;
					count += 1;
				}
				else
					a[j] = 0;
			}
			adjacency.add(a);
		/*	if(count > 0)
				adjacency.add(a);
			else
			{
				flag = 1;
				break;
			}*/
		}

		//if(flag == 1)
		//	setCstar();
	}
	
	void displayAdjacencyMatrix()
	{
		int i, j, a[];
		
		System.out.println("ADJACENCY MATRIX: ");
		for(i = 0; i < SENSOR_MAX; i++)
		{
			a = adjacency.get(i);
			for(j = 0; j < MAX; j++)
				System.out.print(a[j] + " ");
			System.out.println();
		}
	}
	
	
	private boolean getJob(int v)
	{
		int i, j, a[] = adjacency.get(v);
		
		for(i = 0; i < MAX; i++)
		{
			
			if(a[i] == 1 && assigned[i] == 0)
			{
				assigned[i] = 1;
				
					
				if(assigned_sensor[i] < 0 || getJob(assigned_sensor[i]))
				{
					assigned_sensor[i] = v;
					return true;
				}
			}
		}
		
		return false;
	}
	
	
	private int cardinalityOfMatching()
	{
		int i, j, card = 0;
		
		
		for(j = 0; j < MAX; j++)
			assigned_sensor[j] = -1;
		
		for(i = 0; i < SENSOR_MAX; i++)
		{
			assigned = new int[MAX];
			for(j = 0; j < MAX; j++)
				assigned[j] = 0;
			
			
			if(getJob(i))
				card++;
		}
		/*
		this.displayAdjacencyMatrix();
		System.out.println("THE ASSIGNMENT OF SENSORS:");
		for(i = 0; i < MAX; i++)
			System.out.println("SENSOR " + (assigned_sensor[i]+1) + " COVERS TARGET " + (i+1));
		*/
		System.out.println("MAXIMUM MATCHING CARDINALITY: " + card + "\n");
		this.b = Arrays.binarySearch(c1D, this.cstar);
		return card;
	}
	
	double getMaximumMovementDistance()
	{
		int card;
		constructCostMatrix();
		constructAdjacencyMatrix();
		card = cardinalityOfMatching();
		
		while(card != this.MAX)
		{
			setCstar();
			card = cardinalityOfMatching();
		}
		
		this.mid = (this.a + this.b) / 2;
		System.out.println("SEARCH BETWEEN INDICES: " + this.a + " - " + this.b);
		System.out.println("VALUES AT INDICES " + this.a + " AND " + this.b + " ARE " + this.c1D[this.a] + " AND " + this.c1D[this.b] + " RESPECTIVELY");
		System.out.println("MID-POINT IS " + this.mid + " WITH VALUE: " + this.c1D[this.mid]);
		return Double.parseDouble(df.format(this.c1D[this.mid]+this.r));
	}
	
	double getLB()
	{
		return this.c1D[this.a];
	}
	
	double getUB()
	{
		return this.c1D[this.b];
	}
	
	int TestForOptimality()
	{
		if(this.a == this.b)
			return 1;
		return 0;
	}
	
	double binarySearch(int v)
	{
		//If v is positive, then it means that we want the next higher value, else the lower one
		if(v > 0)
		{
			if((this.b - this.mid) > 1)
			{
				System.out.println("THE SEARCH SPACE SIZE: " + (this.b - this.mid));
				this.a = this.mid;
				this.mid = (this.a + this.b) / 2;
				System.out.println("SEARCH BETWEEN MID-POINT AND END POINT: " + this.a + " " + this.mid + "  " + this.b + " : " + this.c1D[this.mid]);
				return (Double.parseDouble(df.format(this.c1D[this.mid] + this.r)));
			}
			else
				return -1;
		}
		else
		{
			if((this.mid - this.a) > 1)
			{
				System.out.println("THE SEARCH SPACE SIZE: " + (this.mid - this.a));
				this.b = this.mid;
				this.mid = (this.a + this.b) / 2;
				System.out.println("SEARCH BETWEEN FRONT POINT AND MID-POINT: " + this.a + " " + this.mid + "  " + this.b + " : " + this.c1D[this.mid]);
				return (Double.parseDouble(df.format(this.c1D[this.mid] + this.r)));
			}
			else
				return -1;
		}
	}
	
	double linearSearch()
	{
		System.out.println("LINEAR SEARCH BETWEEN INDICES: " + this.a + " AND " + this.b);
		
		if(this.a < this.b)
			return (Double.parseDouble(df.format(this.c1D[(this.a)++] + this.r)));
		else
			return (Double.parseDouble(df.format(this.c1D[this.a] + this.r)));
	}
}
