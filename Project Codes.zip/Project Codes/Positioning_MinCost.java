package positioning;
import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.Font;
import java.awt.font.TextAttribute;
import java.util.List;
import java.util.*;
import java.text.*;

public class Positioning_MinCost extends JPanel
{
	int array[] = {50, 75, 100, 150, 200}; 
	int MAX = array[0], SENSOR_MAX = array[0], DIMENSION = 450, itr = 1;
	double MAX_MOVEMENT_DISTANCE = 90.0, r = 30.000; 
	List<TargetPoints> points = new ArrayList<TargetPoints>();
	List<SensorPoints> newPositions = new ArrayList<SensorPoints>();
	List<IntersectionPoints> intersection = new ArrayList<IntersectionPoints>();
	List<PointsInRange> range = new ArrayList<PointsInRange>();
	List<SensorPoints> sensor = new ArrayList<SensorPoints>();
	List<ClosePoints> close = new ArrayList<ClosePoints>();
	List<SensorDistance> distance = new ArrayList<SensorDistance>();
	File file = new File("Input.dat");
	int [] positions = new int[SENSOR_MAX];
	double computed_cost = 0.0, optimum_cost = 0.0;
	Random rand = new Random();
	DecimalFormat df = new DecimalFormat("#.#####");
	
	//Generate the random co-ordinates which are to be plotted
	public void getcoordinates()
	{
		int x, y, count = 1;
		//double theta = (2 * Math.PI / 11);
		rand.setSeed(1155);
		TargetPoints p;		
		
		try
		{
			BufferedWriter bf = new BufferedWriter(new FileWriter("TargetPoints.txt"));
			bf.write("TARGET POINTS :-");
			bf.newLine();
			while(count <= MAX)
			{	
				x = rand.nextInt(DIMENSION);
				y = rand.nextInt(DIMENSION);
				p = new TargetPoints(x, y);
				p.setIndex(count);
				points.add(p);
				bf.append(Integer.toString(x) + ", " + Integer.toString(y));
				bf.newLine();
				count++;
			}
			/*
			while(count < MAX)
			{
				x = (int)Math.round(225 + (70 * Math.cos(count * theta)));
				y = (int)Math.round(225 + (70 * Math.sin(count * theta)));
				System.out.println(x + " " + y);
				p = new Point(x, y);
				points.add(p);
				bf.append(Integer.toString(x) + ", " + Integer.toString(y));
				bf.newLine();
				count++;
			}
			*/
			bf.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	//Generate the random co-ordinates for sensors which are to be plotted
	public void getSensors()
	{
		int x, y, count = 1, i;
		SensorPoints s;
		
		try
		{
			BufferedWriter bf = new BufferedWriter(new FileWriter("SensorPoints.txt"));
			bf.write("SENSOR POINTS :-");
			bf.newLine();
			while(count <= SENSOR_MAX)
			{	
				x = rand.nextInt(DIMENSION);
				y = rand.nextInt(DIMENSION);
				//x = y = 225;
				s = new SensorPoints(x, y);
				s.setIndex(count);
				sensor.add(s);
				bf.append(Integer.toString(x) + ", " + Integer.toString(y));
				bf.newLine();
				count++;
			}
			bf.close();
			
			for(i = 0; i < SENSOR_MAX; i++)
				positions[i] = -1;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	

	void computeSensorDistance()
	{
		SensorDistance sd;
		String str;
		int j, k, l, count = 1;
		List<String[]> s1 = new ArrayList<String[]>();

		for(SensorPoints s : sensor)
		{
			l = 0; 
			j = sensor.size(); 
			k = sensor.size()+intersection.size();
			
			for(SensorPoints sen : sensor)
			{
				l += 1;
				sd = new SensorDistance(s, sen.getX(), sen.getY());
				str = Integer.toString(count) + "," + Integer.toString(l) + "," + df.format(sd.EuclideanDistance());
				s1.add(str.split(","));
				distance.add(sd);
			}
			for(IntersectionPoints i : intersection)
			{
				j += 1;
				sd = new SensorDistance(s, i.getX(), i.getY());
				str = Integer.toString(count) + "," + Integer.toString(j) + "," + df.format(sd.EuclideanDistance());
				s1.add(str.split(","));
				distance.add(sd);
			}	
			
			for(ClosePoints c : close)
			{
				k += 1;
				sd = new SensorDistance(s, c.getX(), c.getY());
				sd.EuclideanDistance();
				distance.add(sd);
				str = Integer.toString(count) + "," + Integer.toString(k) + "," + Double.toString(sd.EuclideanDistance());
				s1.add(str.split(","));
			}
			count += 1;
		}
	}
	
	//Compute the intersection points for the plotted random points
	void getIntersectionPoints()
	{
		int i, j, count;
		TargetPoints p1, p2;
		IntersectionPoints i1, i2;
		double R, l, h, x1, x2, y1, y2, d, m, xm, ym;
		
		try
		{
			BufferedWriter bf = new BufferedWriter(new FileWriter("IntersectionPoints.txt"));
			bf.write("INTERSECTION POINTS :-");
			bf.newLine();
			for(i = 0; i < MAX-1; i++)
			{
				p1 = points.get(i);
				for(j = i+1; j < MAX; j++)
				{
					p2 = points.get(j);
					d = Double.parseDouble(df.format(Math.sqrt(Math.pow(p2.getX() - p1.getX(), 2) + Math.pow(p2.getY() - p1.getY(), 2))));
					if(d >= 0.0 && Double.compare(2*r, d) >= 0) //Not less than equals to 2r since it stops the NAN error in calculation of h 
					{
						xm = (p1.getX() + p2.getX()) / 2.0;
						ym = (p1.getY() + p2.getY()) / 2.0;
						
						if((p2.getX() - p1.getX()) != 0)
						{
							m = (double)(p2.getY() - p1.getY())/(p2.getX() - p1.getX());    //Slope
							if(((4*r*r) - (d*d)) < 0)
								h = 0;
							else
								h = Math.sqrt((4*r*r) - (d*d))/2.0;
					
							x1 = xm + (m * h)/Math.sqrt(1 + (m*m));
							x2 = xm - (m * h)/Math.sqrt(1 + (m*m));
							y1 = ym - h/Math.sqrt(1+(m*m));
							y2 = ym + h/Math.sqrt(1+(m*m));
							
							bf.append("POINTS (" + p1.getX() + " " + p1.getY() + "), (" + p2.getX() + " " + p2.getY() + ") : ");
							bf.append("(" + Double.toString(x1) + ", " + Double.toString(y1) + "), ("  + Double.toString(x2) + ", " + Double.toString(y2) + ")");
							bf.newLine();
							i1 = new IntersectionPoints(Double.parseDouble(df.format(x1)), Double.parseDouble(df.format(y1)));
							i2 = new IntersectionPoints(Double.parseDouble(df.format(x2)), Double.parseDouble(df.format(y2)));
							i1.addPoint(p1);
							i1.addPoint(p2);
							i2.addPoint(p1);
							i2.addPoint(p2);
							intersection.add(i1);
							intersection.add(i2);
							/*System.out.println("POINTS COVERED BY INTERSECTION POINTS: ");
							System.out.println(x1 + " " + y1 + ": " + "(" + i + ", " + j + ")");
							System.out.println(x2 + " " + y2 + ": " + "(" + i + ", " + j + ")");*/
						}
					}
				}	
			}
			bf.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
		
	//To get the points that lie in the range of the intersection points
	void getRangePoints()
	{
		double d;
		int j, k, cir[];
		IntersectionPoints i;
		TargetPoints p;
		PointsInRange c;
		
		//System.out.println("TARGETS IN RANGE OF THE INTERSECTION POINTS :-");
		for(j = 0; j < intersection.size(); j++)
		{								//For every intersection point
			i = intersection.get(j);
			cir = new int[MAX];
			//System.out.print("(" + i.getX() + " " + i.getY() + ") :- ");
			for(k = 0; k < points.size(); k++)
			{							//For every point
				p = points.get(k);
				d = Double.parseDouble(df.format(Math.sqrt(Math.pow(p.getX() - i.getX(), 2) + Math.pow(p.getY() - i.getY(), 2))));
				if(Double.compare(r, d) >= 0 || i.getPoint().contains(p) == true)
				{
					i.addPoint(p);
					cir[k] = 1;
				}
			}
			c = new PointsInRange(cir);
			//c.display();
			range.add(c);
		}
	}
	
	//To get the points that lie in the range of the sensors
	void getSensorRangePoints()
	{
		double d;
		int j, k, pir[];
		SensorPoints s;
		TargetPoints p;
		PointsInRange c;
		
		//System.out.println("TARGETS IN RANGE OF THE SENSOR POINTS :-");
		for(j = 0; j < sensor.size(); j++)
		{								//For every sensor point
			s = sensor.get(j);
			pir = new int[MAX];
			//System.out.print("(" + s.getX() + " " + s.getY() + ") :- ");
			for(k = 0; k < points.size(); k++)
			{							//For every point
				p = points.get(k);
				d = Double.parseDouble(df.format(Math.sqrt(Math.pow(p.getX() - s.getX(), 2) + Math.pow(p.getY() - s.getY(), 2))));
				if(Double.compare(r, d) >= 0)
				{
					s.addTarget(p);
					pir[k] = 1;
				}
			}
			c = new PointsInRange(pir);
			//c.display();
			range.add(c);
		}
	}
	
	//To get the close points
	void ClosePoints()
	{
		double d, x, y, k = SENSOR_MAX+intersection.size();
		int i, j, count;
		SensorPoints s;
		TargetPoints p;
		PointsInRange c;
		ClosePoints i1, cp;
		
		try
		{
			BufferedWriter bf = new BufferedWriter(new FileWriter("ClosePoints.txt"));
			bf.write("CLOSE POINTS :-");
			bf.newLine();
			for(j = 0; j < sensor.size(); j++)
			{
				s = sensor.get(j);
				for(i = 0; i < points.size(); i++)
				{
					p = points.get(i);
					d = Double.parseDouble(df.format(Math.sqrt(Math.pow(s.getX() - p.getX(), 2) + Math.pow(s.getY() - p.getY(), 2))));
					if(Double.compare(d, r) >= 0 && Double.compare(this.MAX_MOVEMENT_DISTANCE, d) >= 0)
					{
						x = ((p.getX()*(d-r)) + (s.getX()*r)) / d;
						y = ((p.getY()*(d-r)) + (s.getY()*r)) / d;
					
						bf.append(k++ + ". SENSOR (" + s.getX() +", " + s.getY() + ") AND POINT (" + p.getX() + ", " + p.getY() + ") :");
						bf.append("("+df.format(x) + ", " + df.format(y)+")");
						bf.newLine();
						
						cp = new ClosePoints(Double.parseDouble(df.format(x)), Double.parseDouble(df.format(y)));
						cp.addPoint(p);
						close.add(cp);
					}
				}
			}
			bf.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	//To find the Target points which are in the range of the close points
	void getCloseRangePoints()
	{
		double d;
		ClosePoints c;
		TargetPoints p;
		PointsInRange pr;
		int i, j, pir[];
		
		//System.out.println("TARGETS COVERED BY CLOSE POINTS ARE: ");
		for(i = 0; i < close.size(); i++)
		{
			c = close.get(i);
			pir = new int[MAX];
			//System.out.print("(" + c.getX() + " " + c.getY() + ") :- ");
			for(j = 0; j < points.size(); j++)
			{
				p = points.get(j);
				d = Double.parseDouble(df.format(Math.sqrt(Math.pow(c.getX() - p.getX(), 2) + Math.pow(c.getY() - p.getY(), 2))));
				if(Double.compare(r, d) >= 0 || c.getPoint().contains(p) == true)
				{
					pir[j] = 1;
					c.addPoint(p);
				}
			}
			pr  = new PointsInRange(pir);
			//pr.display();
			range.add(pr);
		}
		System.out.println("ITERATION: " + this.itr + "\n_______________________");
		System.out.println("NUMBER OF POINTS: " + points.size());
		System.out.println("NUMBER OF SENSOR POINTS: " + sensor.size());
		System.out.println("NUMBER OF INTERSECTION POINTS: " +intersection.size());
		System.out.println("NUMBER OF CLOSE POINTS: " + close.size());
		System.out.println("TOTAL NUMBER OF SENSOR POSITION POINTS: " + range.size());
		System.out.println("MAXIMUM MOVEMENT DISTANCE: " + MAX_MOVEMENT_DISTANCE);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Graphics2D g2D = (Graphics2D)g;
		TargetPoints p;
		IntersectionPoints p1;
		SensorPoints s;
		int x, y, count = sensor.size();
		double x1, y1;
		ClosePoints c;
		String str;
		AttributedString as1;
		
		//X-Axis
		g2D.drawLine(0, 0, 450, 0);
		g2D.drawLine(450, 0, 445, 5);
		//Y-Axis
		g2D.drawLine(0, 0, 0, 445);
		g2D.drawLine(0, 450, 5, 445);
		
		//To display the points in the 2D-Plane
		for(int i = 0; i < points.size(); i++)
		{
			p = points.get(i);
			x = (int)p.getX();
			y = (int)p.getY();
			g2D.fillOval(x,  y,  7, 7);
			str = "T" + Integer.toString(i+1);
	    	as1 = new AttributedString(str);
	    	as1.addAttribute(TextAttribute.FAMILY, "bahnschrift semibold");
	    	as1.addAttribute(TextAttribute.WEIGHT, TextAttribute.WEIGHT_MEDIUM);
	    	as1.addAttribute(TextAttribute.SIZE, 13);
	    	as1.addAttribute(TextAttribute.SUPERSCRIPT, TextAttribute.SUPERSCRIPT_SUB, 1, str.length());
			g2D.drawString(as1.getIterator(), (int)p.getX() - 5, (int)p.getY() - 5);
			//g2D.drawOval(x-(int)r, y-(int)r, 2*(int)r, 2*(int)r);
		}
		
		//To display the sensors in the 2D-Plane
		for(int i = 0; i < sensor.size(); i++)
		{
			s = sensor.get(i);
			x = (int)s.getX();
			y = (int)s.getY();
			g2D.setColor(Color.BLUE);
			g2D.fillOval(x,  y,  7, 7);
			str = "S" + Integer.toString(s.getIndex());
	    	as1 = new AttributedString(str);
	    	as1.addAttribute(TextAttribute.FAMILY, "bahnschrift semibold");
	    	as1.addAttribute(TextAttribute.WEIGHT, TextAttribute.WEIGHT_MEDIUM);
	    	as1.addAttribute(TextAttribute.SIZE, 13);
	    	as1.addAttribute(TextAttribute.SUPERSCRIPT, TextAttribute.SUPERSCRIPT_SUB, 1, str.length());
			g2D.drawString(as1.getIterator(), x-5, y-5);
			if(positions[i] != 1 && s.range.size() > 0)
				g2D.drawOval(x-(int)r+1, y-(int)r+1, 2*(int)r, 2*(int)r);
		}
		
		//To display the sensors in the 2D-Plane
		for(int i = 0; i < newPositions.size(); i++)
		{
			s = newPositions.get(i);
			x = (int)s.getX();
			y = (int)s.getY();
			g2D.setColor(Color.MAGENTA);
			g2D.fillOval(x,  y,  7, 7);
			str = "S" + Integer.toString(s.getIndex());
	    	as1 = new AttributedString(str);
	    	as1.addAttribute(TextAttribute.FAMILY, "bahnschrift semibold");
	    	as1.addAttribute(TextAttribute.WEIGHT, TextAttribute.WEIGHT_MEDIUM);
	    	as1.addAttribute(TextAttribute.SIZE, 13);
	    	as1.addAttribute(TextAttribute.SUPERSCRIPT, TextAttribute.SUPERSCRIPT_SUB, 1, str.length());
			g2D.drawString(as1.getIterator(), x-5, y-5);
			if(s.range.size() > 0)
				g2D.drawOval(x-(int)r+1, y-(int)r+1, 2*(int)r, 2*(int)r);
		}
		/*
		//To find the intersection of the circles
		for(int i = 0; i < intersection.size(); i++)
		{
			p1 = intersection.get(i);
			g2D.setColor(Color.RED);
			g2D.fillOval((int)Math.round(p1.getX())-1, (int)Math.round(p1.getY())-1,  5, 5);
			g2D.drawString(Integer.toString(count++), (int)Math.round(p1.getX())-5, (int)Math.round(p1.getY())-5);
		}
		
		//To display the close points
		for(int i = 0; i < close.size(); i++)
		{
			c = close.get(i);
			g2D.setColor(Color.ORANGE);
			g2D.fillOval((int)Math.round(c.getX()), (int)Math.round(c.getY()),  4, 4);
			g2D.drawString(Integer.toString(count++), (int)Math.round(c.getX())-5, (int)Math.round(c.getY())-5);
		}*/
	}
	
	void writeDatFile()
	{
		int i, j, k, l, count = 1, a[], np, flag;
		PointsInRange r;
		String str;
		SensorDistance sd;
		IntersectionPoints in;
		ClosePoints c;
		SensorPoints s, sen;
		
		try
		{
			BufferedWriter br = new BufferedWriter(new FileWriter(file));
			//To write the set value 
			br.write("data;");
			br.newLine();
			
			
			str = "param maxdist := " + df.format(MAX_MOVEMENT_DISTANCE - this.r) + ";";
			br.append(str);
			br.newLine();
			
			br.append("set T := ");
			for(TargetPoints t : points)
			{
				br.newLine();
				br.append(Integer.toString(t.getIndex()));
			}
			br.append(';');
			br.newLine();
			
			br.append("set S := ");
			for(SensorPoints sp : sensor)
			{
				br.newLine();
				br.append(Integer.toString(sp.getIndex()));
			}
			br.append(';');
			br.newLine();			
			
			br.append("set P := ");
			for(i = 1; i <= (sensor.size() + intersection.size() + close.size()); i++)
			{
				br.newLine();
				br.append(Integer.toString(i));
			}
			br.append(';');
			br.newLine();
			
			//To write the value for parameter 'c'
			br.newLine();
			br.append("param c := ");
			count = 1;
			np = 0;
			for(count = 1; count <= SENSOR_MAX; count++)
			{
				s = sensor.get(count-1);
				l = 0; 
				j = sensor.size(); 
				k = sensor.size()+intersection.size();
				flag = 0;
				
				if(positions[count-1] > -1)
				{
					np = positions[count-1] - 1;
					System.out.println(np);
					flag = 1;
				}
				
				for(i = 0; i < SENSOR_MAX; i++)
				{
					sen = sensor.get(i);
					l += 1;
					sd = new SensorDistance(s, sen.getX(), sen.getY());
					br.newLine();
					if(flag == 1 && (i+1) == count && i != np)
						str = Integer.toString(count) + " " + Integer.toString(l) + " " + df.format(DIMENSION);
					else
					{
					if(flag == 1 && np < SENSOR_MAX && i == np)
						str = Integer.toString(count) + " " + Integer.toString(l) + " " + df.format(0.00);
					else
						str = Integer.toString(count) + " " + Integer.toString(l) + " " + df.format(sd.EuclideanDistance());
					}
					br.append(str);
					distance.add(sd);
				}
				for(i = 0; i < intersection.size(); i++)
				{
					in = intersection.get(i);
					j += 1;
					br.newLine();
					sd = new SensorDistance(s, in.getX(), in.getY());
					if(flag == 1)
					{
						if((np >= SENSOR_MAX && np < (SENSOR_MAX + intersection.size())) && (i == (np-SENSOR_MAX)))
							str = Integer.toString(count) + " " + Integer.toString(j) + " " + df.format(0.00);
						else
							str = Integer.toString(count) + " " + Integer.toString(j) + " " + df.format(DIMENSION);
					}
					else
						str = Integer.toString(count) + " " + Integer.toString(j) + " " + df.format(sd.EuclideanDistance());
					br.append(str);
					distance.add(sd);
				}	
				for(i = 0; i < close.size(); i++)
				{
					c = close.get(i);
					k += 1;
					br.newLine();
					sd = new SensorDistance(s, c.getX(), c.getY()); 
					if(flag == 1)
					{
						if(np >= (SENSOR_MAX + intersection.size()) && (i == (np-SENSOR_MAX-intersection.size())))
							str = Integer.toString(count) + " " + Integer.toString(k) + " " + df.format(0.00);
						else
							str = Integer.toString(count) + " " + Integer.toString(k) + " " + df.format(DIMENSION);
					}
					else
						str = Integer.toString(count) + " " + Integer.toString(k) + " " + df.format(sd.EuclideanDistance());
					br.append(str);
					distance.add(sd);
				}
			}
			br.append(';');
			br.newLine();
			
			//To write the value for parameter 's'
			br.newLine();
			br.append("param s := ");
			for(i = 0; i < range.size(); i++)
			{
				r = range.get(i);
				a = r.getPoints();
				for(j = 0; j < a.length; j++)
				{
					br.newLine();
					str = Integer.toString(i+1) + " " + Integer.toString(j+1) + " " + Integer.toString(a[j]);
					br.append(str);
				}
			}
			br.append(';');
			br.newLine();
			
			br.close();
			
			System.out.println("WRITE OPERATION ON INPUT FILE IS COMPLETE");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	void displayCost(int x1, int y1, double x2, double y2)
	{
		System.out.println("\nMovement Cost = (" + x1 + " " + y1 + ") and (" + x2 + " " + y2 + ") = " + this.getCost(x1, y1, x2, y2));
	}
	
	double getCost(int x1, int y1, double x2, double y2)
	{
		return Double.parseDouble(df.format(Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2))));
	}
	
	int ReadSolution()
	{
		int interNum = intersection.size(), i = 0, sp, np, scount = 0, frac_sp = 0, frac_flag = 0;
		double x, y, cost, min_frac_cost = Double.MAX_VALUE;
		String s, str[];
		long fileSizeBefore, fileSizeAfter;
		List<TargetPoints> targets_in_range;
		SensorPoints sps, frac = null;
		File sol = new File("Solution.sol");
		newPositions.clear();
		computed_cost = 0.00;
		
		try
		{
			System.out.println("FINDING LP SOLUTION:- ");
			Process p = Runtime.getRuntime().exec(".\\w64\\glpsol --math -m C:\\gusek\\examples\\PractiseExamples\\Project\\SensorPositionsLPmodified.mod -d C:\\Users\\Lenovo\\eclipse-workspace\\Project\\Input.dat -y C:\\Users\\Lenovo\\eclipse-workspace\\Project\\Solution.sol --write C:\\Users\\Lenovo\\eclipse-workspace\\Project\\Output.wri " + "");
			//Thread.sleep((SENSOR_MAX * (SENSOR_MAX / 50)) * 1000);
			Thread.sleep(SENSOR_MAX * 1100);
			
			//To provide time for the file write operation
			int flag = 1;
			while(flag == 1)
			{
				fileSizeBefore = sol.length();
				System.out.println("FILE SIZE: " + fileSizeBefore);
				Thread.sleep(60000);
				fileSizeAfter = sol.length();
				System.out.println("FILE SIZE: " + fileSizeAfter);
				
				if (fileSizeBefore == fileSizeAfter)
					flag = 0;
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getCause());
		}
		try
		{
			System.out.println("READING FILE: ");
			
			BufferedReader output = new BufferedReader(new FileReader("Output.wri"));
			while((s = output.readLine()) != null)
			{
				if(s.contains("STATUS") || s.contains("Status") || s.contains("status"))
				{
					System.out.println(s);
					if(!s.contains("OPTIMAL"))
						System.exit(0);
					break;
				}
			}
				
			//To read the solution file created by the execution of the glpk program
			BufferedReader f = new BufferedReader(new FileReader("Solution.sol"));
			
			while((s = f.readLine()) != null)
			{
				if(s.equalsIgnoreCase("\n"))
					continue;
				if(s.contains("TOTAL COST"))
				{
					if(itr == 1)
					{
						this.optimum_cost = Double.parseDouble(s.substring(12));
						System.out.println("OPTIMUM COST: " + this.optimum_cost);
					}
					break;
				}
				
				else
				{
					str = s.split(",");
					
					if(Double.parseDouble(str[2]) > 0.0)
					{
						sp = Integer.parseInt(str[0])-1;
						np = Integer.parseInt(str[1])-1;
						if(sp != np)
						{
							if(np < SENSOR_MAX)
							{
								System.out.println((sp+1) + " SENSOR " + (np+1));
								x = sensor.get(np).getX();
								y = sensor.get(np).getY();
								targets_in_range = sensor.get(np).range; 
								System.out.print((sp+1) + ": ");
								for(TargetPoints p : targets_in_range)
									System.out.print(p.getIndex() + "  ");
								displayCost(sensor.get(sp).getX(), sensor.get(sp).getY(), x, y);
							}
							else if(np >= SENSOR_MAX && np < (SENSOR_MAX + interNum))
							{
								System.out.println((sp+1) + " INTERSECTION " + (np+1));
								x = intersection.get(np-SENSOR_MAX).getX();
								y = intersection.get(np-SENSOR_MAX).getY();
								targets_in_range = intersection.get(np - SENSOR_MAX).getPoint(); 
								System.out.print((sp+1) + ": ");
								for(TargetPoints p : targets_in_range)
									System.out.print(p.getIndex() + "  ");
								displayCost(sensor.get(sp).getX(), sensor.get(sp).getY(), x, y);
							}
							else
							{
								System.out.println((sp+1) + " CLOSE " + (np+1));
								x = close.get(np-SENSOR_MAX-interNum).getX();
								y = close.get(np-SENSOR_MAX-interNum).getY();
								targets_in_range = close.get(np-SENSOR_MAX -interNum).getPoint(); 
								System.out.print((sp+1) + ": ");
								for(TargetPoints p : targets_in_range)
									System.out.print(p.getIndex() + "  ");
								displayCost(sensor.get(sp).getX(), sensor.get(sp).getY(), x, y);
							}
						}
						else
						{
							System.out.println((sp+1) + " SENSOR " + (np+1));
							x = sensor.get(sp).getX();
							y = sensor.get(sp).getY();
							targets_in_range = sensor.get(sp).range; 
							System.out.print((sp+1) + ": ");
							for(TargetPoints p : targets_in_range)
								System.out.print(p.getIndex() + "  ");	
							displayCost(sensor.get(sp).getX(), sensor.get(sp).getY(), x, y);
						}
						
						System.out.println();
						if(Double.parseDouble(str[2]) == 1.0)
						{
							computed_cost += getCost(sensor.get(sp).getX(), sensor.get(sp).getY(), x, y);
							//System.out.println("Cost: " + this.computed_cost);
							sps = new SensorPoints((int)Math.round(x), (int)Math.round(y));
							sps.range = targets_in_range;
							sps.setIndex(sp+1);
							newPositions.add(sps);
						}
						else
						{
							scount++;
							System.out.println("FRACTIONAL VALUES: SENSOR " + (sp+1) + " " + (np+1));
							if(min_frac_cost > getCost(sensor.get(sp).getX(), sensor.get(sp).getY(), x, y) && (sp != np))	//sp!=np, since otherwise the point with no movement is selected
							{
								min_frac_cost = getCost(sensor.get(sp).getX(), sensor.get(sp).getY(), x, y);
								frac_sp = sp;
								frac = new SensorPoints((int)Math.round(x), (int)Math.round(y));
								frac.range = targets_in_range;
								frac.setIndex(np+1);
								frac_flag = 1;
								System.out.println(min_frac_cost + " COST TO MOVE SENSOR " + sp + " TO " + np);
							}
						}
					}	
				}
				
			}
			if(frac_flag == 1)
			{
				System.out.println("SENSOR " + (frac_sp+1) + " IS FORCEFULLY ASSIGNED TO " + frac.getIndex() + "\n\n");
				computed_cost += getCost(sensor.get(frac_sp).getX(), sensor.get(frac_sp).getY(), frac.getX(), frac.getY());
				System.out.println("Cost: " + this.computed_cost + "\n\n");
				positions[frac_sp] = frac.getIndex();
				frac.setIndex(frac_sp+1);
				newPositions.add(frac);
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		//Return 1 if integer solution is found, otherwise return 0
		if(scount == 0 && newPositions.size() == SENSOR_MAX)
		{
			System.out.println("\nALL THE TARGETS ARE COVERED\nALL THE SENSORS ARE ASSIGNED\n");			
			return 1;
		}
		else
		{
			//scount/2  SENSORS HAVE FRACTIONAL VALUES FOUND 
			System.out.println(newPositions.size() + " SENSORS ARE ASSIGNED\n\n");
			return 0;
		}
	}
	
	public static void main(String args[])
	{
		DecimalFormat df = new DecimalFormat("#.#####");
		JFrame f = new JFrame("POINTS PLOTTING");
		Positioning_MinCost p = new Positioning_MinCost();
		p.getcoordinates();
		p.getSensors();
		p.getIntersectionPoints();
		p.ClosePoints();
		p.computeSensorDistance();
		p.getSensorRangePoints();
		p.getRangePoints();
		p.getCloseRangePoints();
		p.writeDatFile();
		
		SwingUtilities.invokeLater(new Runnable() {
			public void run()
			{
				f.getContentPane().add((new JPanel()).add(p));
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f.setSize(p.DIMENSION + 100, p.DIMENSION + 100);
				f.setVisible(true);
			}
		});
		
		while(p.ReadSolution() == 0)
		{
			p.writeDatFile();
			(p.itr)++;
		}
		
		System.out.println("SUB-OPTIMUM COST IS: " + df.format(p.computed_cost) + " pi");
		System.out.println("OPTIMUM COST IS: " + df.format(p.optimum_cost) + " pi");
		/*
		try
		{
			BufferedWriter br = new BufferedWriter(new FileWriter("MinCost" + Integer.toString(p.MAX) + ".txt", true));
			br.append(Integer.toString(p.SENSOR_MAX) + ": " + df.format(p.computed_cost/3));
			br.newLine();
			System.out.println("SUB-OPTIMUM COST IS: " + df.format(p.computed_cost) + " pi");
			br.close();

			br = new BufferedWriter(new FileWriter("Optimal" + Integer.toString(p.MAX) + ".txt", true));
			br.append(Integer.toString(p.SENSOR_MAX) + ": " + df.format(p.optimum_cost/3));
			br.newLine();
			System.out.println("OPTIMUM COST IS: " + df.format(p.optimum_cost) + " pi");
			br.close();
			
			br = new BufferedWriter(new FileWriter("MinCost" + Integer.toString(p.SENSOR_MAX) + "S.txt", true));
			br.append(Integer.toString(p.MAX) + ": " + df.format(p.computed_cost/3));
			br.newLine();
			br.close();

			br = new BufferedWriter(new FileWriter("Optimal" + Integer.toString(p.SENSOR_MAX) + "S.txt", true));
			br.append(Integer.toString(p.MAX) + ": " + df.format(p.optimum_cost/3));
			br.newLine();
			br.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getLocalizedMessage());
		}
		*/
		SwingUtilities.invokeLater(new Runnable() {
			public void run()
			{
				f.repaint();
			}
		});
	}
}
