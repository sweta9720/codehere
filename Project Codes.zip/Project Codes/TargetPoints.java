package positioning;
import java.util.*;
import java.awt.Point;

public class TargetPoints 
{
	private int x, y, index;		//index is used only for display purpose
	private int p[];
	
	TargetPoints(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	
	void setIndex(int index)
	{
		this.index = index;
	}
	
	int getIndex()
	{
		return this.index;
	}
	
	int getX()
	{
		return this.x;
	}
	
	int getY()
	{
		return this.y;
	}
}
