package positioning;

public class SensorDistance 
{
	private SensorPoints s;
	private double x, y, dist;
	
	SensorDistance(SensorPoints s, double x, double y)
	{
		this.s = s;
		this.x = x;
		this.y = y;
	}
	
	double EuclideanDistance()
	{
		this.dist = Math.sqrt(Math.pow(this.x - this.s.getX(), 2) + Math.pow(this.y - this.s.getY(), 2));
		//this.dist = Math.abs(this.x - this.s.x) + Math.abs(this.y - this.s.y);
		return this.dist;
	}
	
	double ManhattanDistance()
	{
		this.dist = Math.abs(this.x - this.s.getX()) + Math.abs(this.y - this.s.getY());
		return this.dist;
	}
	
	void display()
	{
		System.out.println("SENSOR (" + this.s.getX() + ", " + this.s.getY() + ") POSITION (" + this.x + ", " + this.y + ") DISTANCE : " +this.dist);
	}
}