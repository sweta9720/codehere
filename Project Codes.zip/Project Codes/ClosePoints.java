package positioning;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

public class ClosePoints
{
	private double x, y;
	private List<TargetPoints> range;
	
	ClosePoints() 
	{
		range = new ArrayList<TargetPoints>();
	}
	
	ClosePoints(double x, double y) 
	{	
		this.x = x;
		this.y = y;
		range = new ArrayList<TargetPoints>();
	}

	List<TargetPoints> getPoint()
	{
		return this.range;
	}
	
	void addPoint(TargetPoints p)
	{
		if(this.range.contains(p) == false)
			this.range.add(p);
	}
	
	void displayList()
	{
		for(TargetPoints p : this.range)
			System.out.print("( " + (int)p.getX() + " " + (int)p.getY() + " )  ");
		System.out.println();
	}
	
	void setPoints(int x, int y) 
	{	
		this.x = x;
		this.y = y;
	}
	
	double getX()
	{
		return this.x;
	}
	double getY()
	{
		return this.y;
	}
}
