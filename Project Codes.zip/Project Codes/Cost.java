package positioning;

//Redundant class, not used in code anywhere
public class Cost
{
	private double c[];
	
	Cost(double []c)
	{
		this.c = c;
	}
	
	double[] returnCost()
	{
		return this.c;
	}
	
	void display()
	{
		int i;
		
		System.out.println(this.c);
		for(i = 0; i < this.c.length; i++)
			System.out.println(c[i]);
	}
}
