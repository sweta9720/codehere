package positioning;
import java.util.Formatter;
//To provide structure for storing the points which are in the range of the intersection points

public class PointsInRange 
{
	private int p[];
	
	PointsInRange (int p[])
	{
		this.p = p;
	}
	
	int[] getPoints()
	{
		return this.p;
	}
	
	void setPoints(int p[])
	{
		this.p = p;
	}
	
	void display()
	{
		Formatter fm = new Formatter();
		for(int i = 0; i < this.p.length; i++)
			fm.format("%2d", p[i]);
		System.out.println(fm);
	}
}
