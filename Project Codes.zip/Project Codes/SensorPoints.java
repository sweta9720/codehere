package positioning;
import java.util.*;
import java.awt.Point;

public class SensorPoints 
{
	private int x, y, index;		//index is used only for display purpose
	private int p[];
	List<TargetPoints> range;
	
	SensorPoints(int x, int y)
	{
		this.range = new ArrayList<TargetPoints>();
		this.x = x;
		this.y = y;
	}
	
	void setIndex(int index)
	{
		this.index = index;
	}
	
	int getIndex()
	{
		return this.index;
	}
	
	void inputRange(List<TargetPoints> r)
	{
		for(TargetPoints t : r)
			this.range.add(t);
	}
	
	void addTarget(TargetPoints p)
	{
		if(this.range.contains(p) == false)
			this.range.add(p);
	}
	
	void display()
	{
		for(TargetPoints p: this.range)
			System.out.println(p.getX() + " " + p.getY());
	}
	
	int getX()
	{
		return this.x;
	}
	
	int getY()
	{
		return this.y;
	}
}
